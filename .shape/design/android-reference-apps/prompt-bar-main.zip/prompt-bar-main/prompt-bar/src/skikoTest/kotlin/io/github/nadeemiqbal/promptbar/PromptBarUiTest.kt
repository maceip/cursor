package io.github.nadeemiqbal.promptbar

import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.test.ExperimentalTestApi
import androidx.compose.ui.test.assertHasClickAction
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.runComposeUiTest
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

/**
 * Compose UI tests for [PromptBar]. Skiko-backed — Desktop + iOS.
 *
 * State machine itself is exhaustively covered by `PromptBarStateTest` in `commonTest` (no
 * composition required). These tests verify the rendered wiring — test tags, click handlers,
 * autocomplete panels.
 */
@OptIn(ExperimentalTestApi::class)
class PromptBarUiTest {

    @Test
    fun root_renders() = runComposeUiTest {
        val state = PromptBarState()
        setContent {
            MaterialTheme { PromptBar(state = state, onSend = {}) }
        }
        onNodeWithTag("prompt_bar").assertIsDisplayed()
        onNodeWithTag("prompt_bar_textfield", useUnmergedTree = true).assertIsDisplayed()
        onNodeWithTag("prompt_bar_send", useUnmergedTree = true).assertIsDisplayed()
    }

    @Test
    fun sendDisabled_whenComposerEmpty() = runComposeUiTest {
        val state = PromptBarState()
        setContent {
            MaterialTheme { PromptBar(state = state, onSend = {}) }
        }
        assertEquals(SendState.Disabled, state.sendState)
    }

    @Test
    fun sendEnabled_whenTextTyped() = runComposeUiTest {
        val state = PromptBarState()
        setContent {
            MaterialTheme { PromptBar(state = state, onSend = {}) }
        }
        state.fieldValue = TextFieldValue("hello")
        waitForIdle()
        assertEquals(SendState.Ready, state.sendState)
        onNodeWithTag("prompt_bar_send", useUnmergedTree = true).assertHasClickAction()
    }

    @Test
    fun sendButtonFiresOnSend() = runComposeUiTest {
        var sentCount = 0
        val state = PromptBarState()
        setContent {
            MaterialTheme { PromptBar(state = state, onSend = { sentCount++ }) }
        }
        state.fieldValue = TextFieldValue("hello")
        waitForIdle()
        onNodeWithTag("prompt_bar_send", useUnmergedTree = true).performClick()
        assertEquals(1, sentCount)
    }

    @Test
    fun stopButtonFiresOnStop_whenStreaming() = runComposeUiTest {
        var stopCount = 0
        val state = PromptBarState()
        setContent {
            MaterialTheme { PromptBar(state = state, onSend = {}, onStop = { stopCount++ }) }
        }
        state.fieldValue = TextFieldValue("hello")
        state.markStreaming()
        waitForIdle()
        onNodeWithTag("prompt_bar_send", useUnmergedTree = true).performClick()
        assertEquals(1, stopCount)
    }

    @Test
    fun voiceButton_rendersAndFires_whenWired() = runComposeUiTest {
        var voiceTaps = 0
        val state = PromptBarState()
        setContent {
            MaterialTheme {
                PromptBar(state = state, onSend = {}, onVoiceTap = { voiceTaps++ })
            }
        }
        onNodeWithTag("prompt_bar_voice", useUnmergedTree = true).assertIsDisplayed()
        onNodeWithTag("prompt_bar_voice", useUnmergedTree = true).performClick()
        assertEquals(1, voiceTaps)
    }

    @Test
    fun voiceButton_omittedWhenNotWired() = runComposeUiTest {
        val state = PromptBarState()
        setContent {
            MaterialTheme { PromptBar(state = state, onSend = {}) }
        }
        // Voice button should not exist when onVoiceTap is null.
        onNodeWithTag("prompt_bar_voice", useUnmergedTree = true).assertDoesNotExist()
    }

    @Test
    fun slashPanel_appearsWhenTriggerActive() = runComposeUiTest {
        val state = PromptBarState()
        setContent {
            MaterialTheme {
                PromptBar(
                    state = state,
                    onSend = {},
                    slashCommands = listOf(SlashCommand("help", "Show help")),
                )
            }
        }
        state.fieldValue = TextFieldValue("/", selection = TextRange(1))
        waitForIdle()
        onNodeWithTag("prompt_bar_slash_panel", useUnmergedTree = true).assertIsDisplayed()
    }

    @Test
    fun slashPanel_clickInsertsCommandAndClosesPanel() = runComposeUiTest {
        var helpFired = 0
        val state = PromptBarState()
        setContent {
            MaterialTheme {
                PromptBar(
                    state = state,
                    onSend = {},
                    slashCommands = listOf(SlashCommand("help", "Show help") { helpFired++ }),
                )
            }
        }
        state.fieldValue = TextFieldValue("/he", selection = TextRange(3))
        waitForIdle()
        onNodeWithTag("prompt_bar_slash_item_help", useUnmergedTree = true).performClick()
        waitForIdle()
        assertEquals("/help ", state.text)
        assertEquals(1, helpFired)
    }

    @Test
    fun mentionPanel_appearsForRegisteredProvider() = runComposeUiTest {
        val state = PromptBarState()
        setContent {
            MaterialTheme {
                PromptBar(
                    state = state,
                    onSend = {},
                    mentionProvider = MentionProvider.fromList(
                        listOf(Mention("a", "alice"), Mention("b", "bob")),
                    ),
                )
            }
        }
        state.fieldValue = TextFieldValue("@a", selection = TextRange(2))
        // Mention provider is suspending — wait briefly for the dropdown to populate.
        waitUntil(timeoutMillis = 2_000) {
            try {
                onNodeWithTag("prompt_bar_mention_panel", useUnmergedTree = true).assertIsDisplayed()
                true
            } catch (_: Throwable) { false }
        }
    }

    @Test
    fun templates_appearWhenEmpty_andHideAfterTyping() = runComposeUiTest {
        val state = PromptBarState()
        setContent {
            MaterialTheme {
                PromptBar(
                    state = state,
                    onSend = {},
                    templates = listOf(PromptTemplate("Summarize", "Please summarize this.")),
                )
            }
        }
        onNodeWithTag("prompt_bar_templates", useUnmergedTree = true).assertIsDisplayed()
        state.fieldValue = TextFieldValue("hi")
        waitForIdle()
        onNodeWithTag("prompt_bar_templates", useUnmergedTree = true).assertDoesNotExist()
    }

    @Test
    fun templateClick_populatesText() = runComposeUiTest {
        val state = PromptBarState()
        setContent {
            MaterialTheme {
                PromptBar(
                    state = state,
                    onSend = {},
                    templates = listOf(PromptTemplate("Summarize", "Please summarize this.")),
                )
            }
        }
        onNodeWithTag("prompt_bar_template_Summarize", useUnmergedTree = true).performClick()
        waitForIdle()
        assertEquals("Please summarize this.", state.text)
    }

    @Test
    fun attachmentChip_renders_andRemoveButtonFires() = runComposeUiTest {
        val state = PromptBarState()
        state.addAttachment(PromptAttachment("a1", "report.pdf", AttachmentPreview.File("pdf")))
        setContent {
            MaterialTheme { PromptBar(state = state, onSend = {}) }
        }
        onNodeWithTag("prompt_bar_attachments", useUnmergedTree = true).assertIsDisplayed()
        onNodeWithTag("prompt_bar_attachment_chip_a1", useUnmergedTree = true).assertIsDisplayed()
        onNodeWithTag("prompt_bar_attachment_remove_a1", useUnmergedTree = true).performClick()
        waitForIdle()
        assertNull(state.attachments.firstOrNull { it.id == "a1" })
    }

    @Test
    fun counterRendersWhenShowCounterIsTrue() = runComposeUiTest {
        val state = PromptBarState()
        state.fieldValue = TextFieldValue("hello")
        setContent {
            MaterialTheme { PromptBar(state = state, onSend = {}) }
        }
        onNodeWithTag("prompt_bar_counter", useUnmergedTree = true).assertIsDisplayed()
    }

    @Test
    fun counterHiddenWhenShowCounterIsFalse() = runComposeUiTest {
        val state = PromptBarState()
        setContent {
            MaterialTheme { PromptBar(state = state, onSend = {}, showCounter = false) }
        }
        onNodeWithTag("prompt_bar_counter", useUnmergedTree = true).assertDoesNotExist()
    }
}
