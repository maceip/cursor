package io.github.nadeemiqbal.promptbar

/**
 * Result of scanning the current text + caret position for an active autocomplete trigger.
 *
 * The state machine pretends typing `/cmd` or `@some.user` opens an autocomplete dropdown as
 * long as the caret is inside the trigger. The first whitespace after the trigger closes it
 * — the closed substring becomes part of the message.
 */
sealed class ActiveTrigger {
    /** No trigger active. */
    data object None : ActiveTrigger()

    /** A slash-command trigger — `query` is everything typed after `/` so far. */
    data class Slash(val query: String, val triggerStart: Int) : ActiveTrigger()

    /** A `@mention` trigger — `query` is everything typed after `@` so far. */
    data class Mention(val query: String, val triggerStart: Int) : ActiveTrigger()
}

/**
 * Inspect [text] + [caretPosition] and return the active autocomplete trigger, if any. The
 * trigger is active when:
 *  - The caret is at or after the trigger character (`/` or `@`)
 *  - The trigger character is the first character in the text **or** the character immediately
 *    before it is whitespace (or a newline). This prevents `email@domain` from spuriously
 *    opening the mentions dropdown.
 *  - There is no whitespace / newline between the trigger character and the caret.
 *
 * Returns [ActiveTrigger.None] otherwise.
 */
fun detectActiveTrigger(text: String, caretPosition: Int): ActiveTrigger {
    if (caretPosition <= 0) return ActiveTrigger.None
    val safeCaret = caretPosition.coerceAtMost(text.length)
    // Walk backwards from the caret looking for a trigger char.
    var i = safeCaret - 1
    while (i >= 0) {
        val c = text[i]
        if (c == '\n' || c == ' ' || c == '\t') return ActiveTrigger.None
        if (c == '/' || c == '@') {
            val isBoundary = i == 0 || text[i - 1].let { it == ' ' || it == '\t' || it == '\n' }
            if (!isBoundary) return ActiveTrigger.None
            val query = text.substring(i + 1, safeCaret)
            return if (c == '/') ActiveTrigger.Slash(query, i) else ActiveTrigger.Mention(query, i)
        }
        i--
    }
    return ActiveTrigger.None
}

/**
 * Replace the active trigger run (`/cmd` or `@something`) with the chosen [replacement] —
 * returns the new text and the new caret position (just after the replacement + a trailing space).
 */
data class TriggerInsertion(val newText: String, val newCaretPosition: Int)

fun insertTriggerReplacement(
    text: String,
    caretPosition: Int,
    trigger: ActiveTrigger,
    replacement: String,
    appendSpace: Boolean = true,
): TriggerInsertion {
    val safeCaret = caretPosition.coerceIn(0, text.length)
    val (start, _) = when (trigger) {
        is ActiveTrigger.Slash -> trigger.triggerStart to safeCaret
        is ActiveTrigger.Mention -> trigger.triggerStart to safeCaret
        ActiveTrigger.None -> return TriggerInsertion(text, safeCaret)
    }
    val before = text.substring(0, start)
    val after = text.substring(safeCaret)
    val suffix = if (appendSpace) " " else ""
    val newText = before + replacement + suffix + after
    val newCaret = (before + replacement + suffix).length
    return TriggerInsertion(newText, newCaret)
}

/**
 * Smart paste-tokenizer. When a user pastes a blob of comma-, semicolon- or newline-separated
 * tokens into the composer (e.g. an email list), break it into individual entries and let the
 * host turn each one into a chip. The tokenizer also trims surrounding whitespace and quotes,
 * and skips blank entries.
 */
fun tokenizePastedBlob(blob: String): List<String> {
    if (blob.isEmpty()) return emptyList()
    return blob.split(',', ';', '\n', '\r', '\t')
        .map { it.trim().trim('"', '\'') }
        .filter { it.isNotEmpty() }
}

/**
 * Naive character → "token" estimator for the live token counter. Models vary in their
 * tokenization, so this is just a "good enough" heuristic — ~4 characters per token, rounded up.
 * Callers that want exact counts can plug in their own tokenizer via [PromptBarState.tokenizer].
 */
fun approximateTokenCount(text: String): Int {
    if (text.isEmpty()) return 0
    return ((text.length + 3) / 4).coerceAtLeast(1)
}
