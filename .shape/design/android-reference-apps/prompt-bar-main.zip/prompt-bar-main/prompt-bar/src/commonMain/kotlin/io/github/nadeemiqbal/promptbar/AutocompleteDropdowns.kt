package io.github.nadeemiqbal.promptbar

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/**
 * The slash-command autocomplete panel. Shows a vertical list of matching commands with
 * highlighting on the matched portion of the query.
 *
 * Visible only while the prompt's [PromptBarState.activeTrigger] is an [ActiveTrigger.Slash] and
 * the filtered list isn't empty.
 */
@Composable
fun SlashAutocompletePanel(
    commands: List<SlashCommand>,
    query: String,
    onSelect: (SlashCommand) -> Unit,
    modifier: Modifier = Modifier,
) {
    val filtered = remember(commands, query) {
        if (query.isEmpty()) commands
        else commands.filter { it.name.contains(query, ignoreCase = true) }
    }
    if (filtered.isEmpty()) return
    Surface(
        modifier = modifier.testTag("prompt_bar_slash_panel"),
        color = MaterialTheme.colorScheme.surface,
        shape = PromptBarDefaults.shape,
        tonalElevation = 2.dp,
        shadowElevation = 4.dp,
    ) {
        LazyColumn(modifier = Modifier.fillMaxWidth()) {
            items(filtered, key = { it.name }) { command ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelect(command) }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .testTag("prompt_bar_slash_item_${command.name}"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "/${command.name}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                        )
                        Text(
                            command.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    if (command.hotkey != null) {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = PromptBarDefaults.chipShape,
                        ) {
                            Text(
                                command.hotkey,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * The `@mention` autocomplete panel. Suggestions are produced asynchronously by the supplied
 * [MentionProvider] — the panel calls `suggest(query)` whenever the query changes and renders
 * the resulting list.
 */
@Composable
fun MentionAutocompletePanel(
    provider: MentionProvider,
    query: String,
    onSelect: (Mention) -> Unit,
    modifier: Modifier = Modifier,
) {
    var suggestions by remember { mutableStateOf<List<Mention>>(emptyList()) }

    // Re-fetch suggestions as the query changes. We don't debounce — that's the caller's job in
    // the provider implementation (e.g. wrap a Room query with a `debounce(200)` operator).
    LaunchedEffect(provider, query) {
        suggestions = provider.suggest(query)
    }

    if (suggestions.isEmpty()) return
    Surface(
        modifier = modifier.testTag("prompt_bar_mention_panel"),
        color = MaterialTheme.colorScheme.surface,
        shape = PromptBarDefaults.shape,
        tonalElevation = 2.dp,
        shadowElevation = 4.dp,
    ) {
        LazyColumn(modifier = Modifier.fillMaxWidth()) {
            items(suggestions, key = { it.id }) { mention ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelect(mention) }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .testTag("prompt_bar_mention_item_${mention.id}"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "@${mention.display}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                        )
                        if (mention.subtitle != null) {
                            Text(
                                mention.subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    if (mention.category != null) {
                        Surface(
                            color = MaterialTheme.colorScheme.tertiaryContainer,
                            shape = PromptBarDefaults.chipShape,
                        ) {
                            Text(
                                mention.category,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onTertiaryContainer,
                            )
                        }
                    }
                }
            }
        }
    }
}

