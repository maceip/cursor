package io.github.nadeemiqbal.promptbar

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.isShiftPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp

/**
 * The composer bar — multi-line auto-growing textfield with attachment chips above, a quick-prompt
 * template row, slash/mention autocomplete dropdowns, voice button, model selector slot, and a
 * Send/Sending/Stop button driven by [state]'s lifecycle.
 *
 * Test tags:
 *  - root: `prompt_bar`
 *  - textfield: `prompt_bar_textfield`
 *  - send button: `prompt_bar_send`
 *  - voice button: `prompt_bar_voice`
 *  - templates row: `prompt_bar_templates`
 *  - attachments row: `prompt_bar_attachments`
 *  - slash panel: `prompt_bar_slash_panel`
 *  - mention panel: `prompt_bar_mention_panel`
 *  - token counter: `prompt_bar_counter`
 */
@Composable
fun PromptBar(
    state: PromptBarState,
    onSend: () -> Unit,
    modifier: Modifier = Modifier,
    onStop: (() -> Unit)? = null,
    onVoiceTap: (() -> Unit)? = null,
    placeholder: String = PromptBarDefaults.DefaultPlaceholder,
    slashCommands: List<SlashCommand> = emptyList(),
    mentionProvider: MentionProvider = MentionProvider.Empty,
    templates: List<PromptTemplate> = emptyList(),
    showCounter: Boolean = true,
    colors: PromptBarColors = PromptBarDefaults.colors(),
    icons: PromptBarIcons = PromptBarDefaults.icons(),
    shape: Shape = PromptBarDefaults.shape,
    chipShape: Shape = PromptBarDefaults.chipShape,
    modelSelector: (@Composable () -> Unit)? = null,
    customAttachmentPreview: ((PromptAttachment) -> (@Composable () -> Unit)?)? = null,
    // When provided, replaces the built-in Send/Stop button in the bottom control row. The slot
    // receives the current [SendState] so a custom control (e.g. a mic that morphs into a send
    // button when the field is non-empty) can react to send-readiness. The `prompt-bar-voice`
    // companion uses this to drop in a hold-to-record mic.
    trailingButton: (@Composable (SendState) -> Unit)? = null,
    // When provided, drawn on top of the text-field area (filling it). Used to take the input
    // over with a live recording strip while a voice message is being captured. `null` content
    // means the textfield shows normally.
    inputOverlay: (@Composable () -> Unit)? = null,
) {
    val focusManager = LocalFocusManager.current

    Column(
        modifier = modifier.testTag("prompt_bar"),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        // Autocomplete panels float above the input.
        when (val trigger = state.activeTrigger) {
            is ActiveTrigger.Slash -> SlashAutocompletePanel(
                commands = slashCommands,
                query = trigger.query,
                onSelect = { command ->
                    val insertion = insertTriggerReplacement(
                        text = state.fieldValue.text,
                        caretPosition = state.fieldValue.selection.end,
                        trigger = trigger,
                        replacement = "/${command.name}",
                    )
                    state.fieldValue = TextFieldValue(
                        text = insertion.newText,
                        selection = androidx.compose.ui.text.TextRange(insertion.newCaretPosition),
                    )
                    command()
                },
            )
            is ActiveTrigger.Mention -> MentionAutocompletePanel(
                provider = mentionProvider,
                query = trigger.query,
                onSelect = { mention ->
                    val insertion = insertTriggerReplacement(
                        text = state.fieldValue.text,
                        caretPosition = state.fieldValue.selection.end,
                        trigger = trigger,
                        replacement = "@${mention.display}",
                    )
                    state.fieldValue = TextFieldValue(
                        text = insertion.newText,
                        selection = androidx.compose.ui.text.TextRange(insertion.newCaretPosition),
                    )
                },
            )
            ActiveTrigger.None -> { /* no panel */ }
        }

        // Templates row — shown above the input when there's no autocomplete active and no input.
        if (templates.isNotEmpty() && state.text.isEmpty() && state.activeTrigger == ActiveTrigger.None) {
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("prompt_bar_templates"),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(templates) { template ->
                    Surface(
                        modifier = Modifier
                            .clip(PromptBarDefaults.chipShape)
                            .testTag("prompt_bar_template_${template.label}"),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = PromptBarDefaults.chipShape,
                        onClick = { state.applyTemplate(template) },
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                        ) {
                            template.icon?.invoke()
                            Text(
                                template.label,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = colors.container,
            shape = shape,
            tonalElevation = 1.dp,
        ) {
            Column(modifier = Modifier.padding(PromptBarDefaults.contentPadding)) {
                // Attachment chips above the textfield.
                if (state.attachments.isNotEmpty()) {
                    LazyRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("prompt_bar_attachments"),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 8.dp),
                    ) {
                        items(state.attachments, key = { it.id }) { attachment ->
                            AttachmentChip(
                                attachment = attachment,
                                onRemove = { state.removeAttachment(attachment.id) },
                                customPreview = customAttachmentPreview?.invoke(attachment),
                                colors = colors,
                                icons = icons,
                                shape = chipShape,
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Bottom,
                ) {
                    // Auto-growing multi-line BasicTextField, with an optional overlay (the voice
                    // recording strip) drawn on top while capturing.
                    Box(modifier = Modifier.weight(1f)) {
                        // While an input overlay (the voice recording strip) is active, the
                        // textfield must not accept input: it sits behind the transparent overlay
                        // and would otherwise swallow keystrokes (hardware keyboard on Desktop, or
                        // a still-focused soft keyboard), leaking typed text in behind the
                        // waveform.
                        //
                        // We use `readOnly` (not `enabled = false`) on purpose: readOnly blocks
                        // all edits but KEEPS focus, so on mobile the soft keyboard stays up when
                        // the user taps the mic mid-typing. That avoids the dismiss/re-show
                        // flicker `enabled = false` (which drops focus) would cause. The empty
                        // field means there's nothing to edit anyway; we just need typing inert.
                        val recordingActive = inputOverlay != null
                        BasicTextField(
                            value = state.fieldValue,
                            onValueChange = { if (!recordingActive) state.fieldValue = it },
                            readOnly = recordingActive,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("prompt_bar_textfield")
                                .padding(vertical = 8.dp)
                                .onKeyEvent { event ->
                                    // Swallow all key events while recording so a hardware Enter
                                    // (or any key) can't act on the field behind the overlay.
                                    if (recordingActive) return@onKeyEvent true
                                    if (event.type == KeyEventType.KeyDown && event.key == Key.Enter && !event.isShiftPressed) {
                                        if (state.sendState == SendState.Ready) {
                                            onSend()
                                            return@onKeyEvent true
                                        }
                                    }
                                    false
                                },
                            textStyle = LocalTextStyle.current.copy(color = colors.textColor),
                            cursorBrush = androidx.compose.ui.graphics.SolidColor(colors.cursorColor),
                            keyboardOptions = KeyboardOptions(
                                capitalization = KeyboardCapitalization.Sentences,
                                imeAction = ImeAction.Send,
                            ),
                            keyboardActions = KeyboardActions(
                                onSend = {
                                    if (state.sendState == SendState.Ready) {
                                        onSend()
                                        focusManager.clearFocus()
                                    }
                                },
                            ),
                            decorationBox = { inner ->
                                // Hide the placeholder while an input overlay (e.g. the voice
                                // recording strip) is covering the field, so it doesn't bleed
                                // through behind a transparent overlay.
                                if (state.text.isEmpty() && inputOverlay == null) {
                                    Text(
                                        placeholder,
                                        style = LocalTextStyle.current.copy(color = colors.placeholderColor),
                                    )
                                }
                                inner()
                            },
                        )
                        // Voice recording strip (or any caller-supplied overlay) sits on top of
                        // the textfield, covering the placeholder while active.
                        if (inputOverlay != null) {
                            Box(modifier = Modifier.matchParentSize()) {
                                inputOverlay()
                            }
                        }
                    }
                }

                // Bottom bar: voice button, model selector, char/token counter, send button.
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    if (onVoiceTap != null) {
                        IconButton(
                            onClick = onVoiceTap,
                            modifier = Modifier.testTag("prompt_bar_voice"),
                        ) {
                            Icon(
                                imageVector = icons.mic,
                                contentDescription = "Voice input",
                                tint = colors.placeholderColor,
                            )
                        }
                    }
                    if (modelSelector != null) {
                        modelSelector()
                    }
                    if (showCounter) {
                        Text(
                            "${state.charCount} chars · ~${state.tokenCount} tokens",
                            modifier = Modifier.testTag("prompt_bar_counter"),
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.counterColor,
                        )
                    }
                    Box(modifier = Modifier.weight(1f))
                    if (trailingButton != null) {
                        trailingButton(state.sendState)
                    } else {
                        SendStopButton(
                            sendState = state.sendState,
                            onSend = onSend,
                            onStop = onStop ?: {},
                            colors = colors,
                            icons = icons,
                        )
                    }
                }
            }
        }
    }
}

/**
 * The single-button Send → Sending → Stop state machine. Visual state derives from `sendState`.
 *
 * - [SendState.Disabled] — disabled with the Send icon.
 * - [SendState.Ready] — enabled with the Send icon, fires [onSend].
 * - [SendState.Sending] — shows a CircularProgressIndicator; click is a no-op.
 * - [SendState.Streaming] — shows the Stop icon, fires [onStop].
 */
@Composable
fun SendStopButton(
    sendState: SendState,
    onSend: () -> Unit,
    onStop: () -> Unit,
    modifier: Modifier = Modifier,
    colors: PromptBarColors = PromptBarDefaults.colors(),
    icons: PromptBarIcons = PromptBarDefaults.icons(),
) {
    FilledIconButton(
        onClick = {
            when (sendState) {
                SendState.Ready -> onSend()
                SendState.Streaming -> onStop()
                SendState.Sending, SendState.Disabled -> { /* no-op */ }
            }
        },
        modifier = modifier
            .size(40.dp)
            .testTag("prompt_bar_send"),
        enabled = sendState == SendState.Ready || sendState == SendState.Streaming,
        colors = IconButtonDefaults.filledIconButtonColors(
            containerColor = colors.sendButtonContainer,
            contentColor = colors.sendButtonContent,
        ),
    ) {
        when (sendState) {
            SendState.Sending -> CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                strokeWidth = 2.dp,
                color = colors.sendButtonContent,
            )
            SendState.Streaming -> Icon(
                imageVector = icons.stop,
                contentDescription = "Stop generating",
            )
            else -> Icon(
                imageVector = icons.send,
                contentDescription = "Send",
            )
        }
    }
}

