package io.github.nadeemiqbal.promptbar

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable

/**
 * Identifier for an attachment chip's preview. Renderers map this to the right preview composable
 * (image thumbnail, generic-file icon with extension, etc.). The lib never opens / decodes files
 * itself — pickers fill these values from your platform layer (FileKit, native pickers, etc.).
 */
sealed class AttachmentPreview {
    /** A bitmap-style image. The renderer is responsible for actually drawing the bytes. */
    data class Image(val sourceTag: String) : AttachmentPreview()

    /** A non-image file. Show an icon with the extension label. */
    data class File(val extension: String) : AttachmentPreview()

    /**
     * A captured voice message. The chip renders a compact waveform built from [samples] plus a
     * `m:ss` duration label. Audio bytes are NOT carried in the preview to keep `PromptAttachment`
     * lightweight: pair with the `prompt-bar-voice` companion artifact (or your own side map) to
     * keep the actual `VoiceAudio` bytes addressable by the attachment id.
     *
     * @param durationSeconds total recording length, used to render the timer next to the
     *   waveform.
     * @param samples per-bar amplitude readings (`0f..1f`) that drove the recorder's live
     *   waveform. Re-used here so the chip's preview matches what the user saw while recording.
     */
    data class Voice(
        val durationSeconds: Int,
        val samples: List<Float>,
    ) : AttachmentPreview()
}

/** One attachment chip in the [PromptBarState.attachments] list. */
@Immutable
data class PromptAttachment(
    val id: String,
    val displayName: String,
    val preview: AttachmentPreview,
    /** Optional human-readable size label, e.g. "120 KB". Rendered next to the name when set. */
    val sizeLabel: String? = null,
)

/** One slash-command option in the autocomplete dropdown. */
@Immutable
data class SlashCommand(
    val name: String,
    val description: String,
    val hotkey: String? = null,
    val onSelect: () -> Unit = {},
) {
    /** Convenience: trigger as the user picks this command — also clears the leading `/text` portion. */
    operator fun invoke() { onSelect() }
}

/** One `@mention` option in the autocomplete dropdown. */
@Immutable
data class Mention(
    val id: String,
    val display: String,
    val subtitle: String? = null,
    /** Optional category tag (e.g. "File", "Person") used to group/visually annotate suggestions. */
    val category: String? = null,
)

/** Source of asynchronous (or synchronous) mention suggestions. */
fun interface MentionProvider {

    /**
     * Compute the suggestion list for the given `query` (the text typed after `@` but before the
     * next whitespace). Returning an empty list closes the dropdown.
     */
    suspend fun suggest(query: String): List<Mention>

    companion object {
        /** A no-op provider used as a default when the host hasn't wired mentions. */
        val Empty: MentionProvider = MentionProvider { emptyList() }

        /** Convenience: build a provider over a static list with case-insensitive substring match. */
        fun fromList(items: List<Mention>): MentionProvider = MentionProvider { query ->
            if (query.isEmpty()) items
            else items.filter { it.display.contains(query, ignoreCase = true) }
        }
    }
}

/** Lifecycle phases of the prompt-bar's Send/Stop button state machine. */
enum class SendState {
    /** No text + no attachments — the Send button is disabled. */
    Disabled,

    /** Composer has content — Send is clickable. */
    Ready,

    /** Caller signalled in-flight delivery — Send shows a spinner; click is ignored. */
    Sending,

    /** Assistant is streaming a reply — the Send icon is swapped to Stop. */
    Streaming,
}

/**
 * One quick-prompt chip rendered above the input. Tapping populates (or replaces) the composer
 * text. Optional [Composable] icon slot.
 */
@Immutable
data class PromptTemplate(
    val label: String,
    val text: String,
    val icon: (@Composable () -> Unit)? = null,
)

/** One model/persona option in the inline model selector. */
@Immutable
data class ModelOption(
    val id: String,
    val name: String,
    val description: String? = null,
)
