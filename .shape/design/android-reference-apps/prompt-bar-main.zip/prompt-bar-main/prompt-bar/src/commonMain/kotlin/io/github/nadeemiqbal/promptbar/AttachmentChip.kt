package io.github.nadeemiqbal.promptbar

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/**
 * A single attachment chip with a preview (image thumbnail icon for [AttachmentPreview.Image],
 * file-extension icon for [AttachmentPreview.File]), the display name, an optional size label,
 * and a remove (X) button.
 *
 * The lib never decodes actual image bytes — preview rendering is intentionally generic so the
 * chip stays a CMP-friendly drop-in for any storage backend. To render true thumbnails, wrap
 * this in your own composable that draws the bitmap above the file name.
 */
@Composable
fun AttachmentChip(
    attachment: PromptAttachment,
    onRemove: () -> Unit,
    modifier: Modifier = Modifier,
    customPreview: (@Composable () -> Unit)? = null,
    colors: PromptBarColors = PromptBarDefaults.colors(),
    icons: PromptBarIcons = PromptBarDefaults.icons(),
    shape: Shape = PromptBarDefaults.chipShape,
) {
    Surface(
        modifier = modifier
            .height(48.dp)
            .testTag("prompt_bar_attachment_chip_${attachment.id}"),
        color = colors.attachmentChipContainer,
        shape = shape,
    ) {
        Row(
            modifier = Modifier.padding(start = 6.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            // Preview slot — either the caller's custom composable, or a built-in icon.
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(colors.attachmentPreviewBackground),
                contentAlignment = Alignment.Center,
            ) {
                when {
                    customPreview != null -> customPreview()
                    attachment.preview is AttachmentPreview.Image -> Icon(
                        imageVector = icons.attachmentImage,
                        contentDescription = null,
                        tint = colors.attachmentChipContent,
                    )
                    attachment.preview is AttachmentPreview.File -> Box(
                        modifier = Modifier.size(36.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            imageVector = icons.attachmentFile,
                            contentDescription = null,
                            tint = colors.attachmentChipContent,
                        )
                        val ext = (attachment.preview as AttachmentPreview.File).extension
                        if (ext.isNotEmpty() && ext.length <= 4) {
                            Text(
                                ext.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = colors.attachmentChipContent,
                            )
                        }
                    }
                    attachment.preview is AttachmentPreview.Voice -> Icon(
                        imageVector = icons.attachmentVoice,
                        contentDescription = null,
                        tint = colors.attachmentChipContent,
                    )
                }
            }
            Column(
                modifier = Modifier.padding(end = 4.dp),
                verticalArrangement = Arrangement.Center,
            ) {
                Text(
                    attachment.displayName,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.attachmentChipContent,
                )
                if (attachment.sizeLabel != null) {
                    Text(
                        attachment.sizeLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.attachmentChipContent.copy(alpha = 0.7f),
                    )
                }
            }
            IconButton(
                onClick = onRemove,
                modifier = Modifier
                    .size(24.dp)
                    .testTag("prompt_bar_attachment_remove_${attachment.id}"),
            ) {
                Icon(
                    imageVector = Icons.Outlined.Close,
                    contentDescription = "Remove ${attachment.displayName}",
                    tint = colors.attachmentChipContent,
                )
            }
        }
    }
}

