package io.github.nadeemiqbal.promptbar

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.GraphicEq
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.InsertDriveFile
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.Send
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Default visual tuning for [PromptBar] and its sub-components. */
object PromptBarDefaults {

    /** Default surface shape for the composer card. */
    val shape: Shape get() = RoundedCornerShape(24.dp)

    /** Default chip shape for slash/mention/template chips and attachment chips. */
    val chipShape: Shape get() = RoundedCornerShape(16.dp)

    /** Default horizontal/vertical padding inside the composer card. */
    val contentPadding: Dp = 12.dp

    /** Default min-height of the textfield row (auto-grows up to a few lines). */
    val minRowHeight: Dp = 48.dp

    /** Default max rows the textfield grows to before scrolling. */
    const val DefaultMaxRows: Int = 6

    /** Default placeholder text. */
    const val DefaultPlaceholder: String = "Send a message…"

    @Composable
    @ReadOnlyComposable
    fun container(): Color = MaterialTheme.colorScheme.surface

    @Composable
    @ReadOnlyComposable
    fun outline(): Color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)

    /**
     * Builds a [PromptBarColors], defaulting every token to the active [MaterialTheme]. Override
     * only the slots you want to rebrand.
     */
    @Composable
    @ReadOnlyComposable
    fun colors(
        container: Color = MaterialTheme.colorScheme.surface,
        textColor: Color = MaterialTheme.colorScheme.onSurface,
        placeholderColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
        cursorColor: Color = MaterialTheme.colorScheme.primary,
        counterColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
        sendButtonContainer: Color = MaterialTheme.colorScheme.primary,
        sendButtonContent: Color = MaterialTheme.colorScheme.onPrimary,
        attachmentChipContainer: Color = MaterialTheme.colorScheme.surfaceVariant,
        attachmentChipContent: Color = MaterialTheme.colorScheme.onSurfaceVariant,
        attachmentPreviewBackground: Color = MaterialTheme.colorScheme.surface,
    ): PromptBarColors = PromptBarColors(
        container = container,
        textColor = textColor,
        placeholderColor = placeholderColor,
        cursorColor = cursorColor,
        counterColor = counterColor,
        sendButtonContainer = sendButtonContainer,
        sendButtonContent = sendButtonContent,
        attachmentChipContainer = attachmentChipContainer,
        attachmentChipContent = attachmentChipContent,
        attachmentPreviewBackground = attachmentPreviewBackground,
    )

    /**
     * Builds a [PromptBarIcons], defaulting every icon to the Material `Outlined` set the library
     * ships with. Pass your own [ImageVector]s to rebrand.
     */
    fun icons(
        send: ImageVector = Icons.Outlined.Send,
        stop: ImageVector = Icons.Outlined.Stop,
        mic: ImageVector = Icons.Outlined.Mic,
        attachmentImage: ImageVector = Icons.Outlined.Image,
        attachmentFile: ImageVector = Icons.Outlined.InsertDriveFile,
        attachmentVoice: ImageVector = Icons.Outlined.GraphicEq,
    ): PromptBarIcons = PromptBarIcons(
        send = send,
        stop = stop,
        mic = mic,
        attachmentImage = attachmentImage,
        attachmentFile = attachmentFile,
        attachmentVoice = attachmentVoice,
    )
}
