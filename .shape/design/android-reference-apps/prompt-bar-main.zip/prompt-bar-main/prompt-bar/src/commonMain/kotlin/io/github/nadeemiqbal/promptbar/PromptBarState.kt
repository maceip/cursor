package io.github.nadeemiqbal.promptbar

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue

/**
 * Headless state container for [PromptBar]. Owns the textfield value, the live list of
 * attachment chips, the current `SendState`, the model selector, and the active autocomplete
 * trigger.
 *
 * Drivable without composition — handy for tests and for hosts that want to mutate the bar from
 * outside (e.g. "Regenerate" button programmatically prepends "Regenerate: " to the textfield).
 */
class PromptBarState internal constructor(
    initialText: String = "",
    initialAttachments: List<PromptAttachment> = emptyList(),
    /**
     * Optional custom tokenizer for the live char/token counter. Defaults to the
     * [approximateTokenCount] heuristic (≈ 4 chars per token).
     */
    var tokenizer: (String) -> Int = ::approximateTokenCount,
    /** Soft upper bound on attachment chips. Attempts to add beyond this are ignored. */
    var maxAttachments: Int = 10,
    /** Soft upper bound on input characters. Excess input is truncated. */
    var maxChars: Int = 32_000,
) {

    // ---- TextFieldValue (text + selection) ---------------------------------------------------

    private var fieldState by mutableStateOf(
        TextFieldValue(text = initialText, selection = TextRange(initialText.length)),
    )

    /** The current `TextFieldValue` — selection-aware, what the BasicTextField actually renders. */
    var fieldValue: TextFieldValue
        get() = fieldState
        set(value) {
            val cappedText = if (value.text.length <= maxChars) value.text else value.text.substring(0, maxChars)
            val cappedSelection = if (cappedText.length == value.text.length) value.selection
            else TextRange(cappedText.length.coerceAtMost(value.selection.end))
            fieldState = value.copy(text = cappedText, selection = cappedSelection)
        }

    /** Convenience: the raw string. */
    val text: String get() = fieldState.text

    // ---- Send/Stop state machine -------------------------------------------------------------

    private var sendOverrideState by mutableStateOf<SendState?>(null)

    /**
     * The derived button state. Use [forceSendState] (or call [markSending] / [markStreaming] /
     * [markReady]) to override the natural Disabled/Ready transition when an in-flight delivery
     * or a streaming response is happening.
     */
    val sendState: SendState
        get() = sendOverrideState ?: if (text.isBlank() && attachments.isEmpty()) SendState.Disabled else SendState.Ready

    /**
     * Override the derived send state (e.g. host knows the assistant just started streaming).
     * Pass `null` to clear the override and revert to derived behaviour.
     */
    fun forceSendState(state: SendState?) {
        sendOverrideState = state
    }

    /** Convenience: pin the button to `Sending` (spinner). */
    fun markSending() = forceSendState(SendState.Sending)

    /** Convenience: pin the button to `Streaming` (Stop icon). */
    fun markStreaming() = forceSendState(SendState.Streaming)

    /** Convenience: revert to derived behaviour (`Ready` if there's content, `Disabled` otherwise). */
    fun markReady() = forceSendState(null)

    // ---- Attachment chips --------------------------------------------------------------------

    private val attachmentsState = mutableStateListOf<PromptAttachment>()

    /** Live list of attachment chips. Mutate via [addAttachment] / [removeAttachment] / [clearAttachments]. */
    val attachments: List<PromptAttachment> get() = attachmentsState

    init {
        attachmentsState.addAll(initialAttachments)
    }

    /** Append an attachment. Returns `false` if the cap is hit; otherwise `true`. */
    fun addAttachment(attachment: PromptAttachment): Boolean {
        if (attachmentsState.any { it.id == attachment.id }) return false
        if (attachmentsState.size >= maxAttachments) return false
        attachmentsState.add(attachment)
        return true
    }

    /** Remove an attachment by id. */
    fun removeAttachment(id: String) {
        attachmentsState.removeAll { it.id == id }
    }

    /** Drop every attachment. */
    fun clearAttachments() {
        attachmentsState.clear()
    }

    // ---- Model selector ----------------------------------------------------------------------

    private var modelState by mutableStateOf<ModelOption?>(null)

    /** The currently-selected model option, or `null` if no selector is wired. */
    val selectedModel: ModelOption? get() = modelState

    fun selectModel(model: ModelOption?) {
        modelState = model
    }

    // ---- Convenience -------------------------------------------------------------------------

    /** Apply a [PromptTemplate] — overwrites the current text with the template's text. */
    fun applyTemplate(template: PromptTemplate) {
        fieldValue = TextFieldValue(text = template.text, selection = TextRange(template.text.length))
    }

    /** Append text at the caret position and move the caret to the end of the inserted text. */
    fun appendAtCaret(text: String) {
        val current = fieldValue
        val caret = current.selection.end
        val before = current.text.substring(0, caret)
        val after = current.text.substring(caret)
        val newText = before + text + after
        fieldValue = TextFieldValue(text = newText, selection = TextRange(before.length + text.length))
    }

    /**
     * Paste the contents of [blob] using the smart [tokenizePastedBlob] logic: each token becomes
     * an attachment with the supplied [makeAttachment] factory. Returns the number of tokens
     * actually inserted (some may be dropped at the cap).
     */
    fun pasteTokensAsAttachments(blob: String, makeAttachment: (String) -> PromptAttachment): Int {
        val tokens = tokenizePastedBlob(blob)
        var inserted = 0
        for (tok in tokens) {
            if (addAttachment(makeAttachment(tok))) inserted++
        }
        return inserted
    }

    /** Clear everything — text, selection, attachments, send-state override. */
    fun reset() {
        fieldState = TextFieldValue("", selection = TextRange.Zero)
        attachmentsState.clear()
        sendOverrideState = null
    }

    /** Read-only snapshot of what the caller would `send()`. */
    val outgoing: PromptBarOutgoing
        get() = PromptBarOutgoing(text = text, attachments = attachments.toList(), model = selectedModel)

    /** Live char count. */
    val charCount: Int get() = text.length

    /** Live token count via the configured [tokenizer]. */
    val tokenCount: Int get() = tokenizer(text)

    /** The active autocomplete trigger derived from the current text + caret position. */
    val activeTrigger: ActiveTrigger
        get() = detectActiveTrigger(fieldState.text, fieldState.selection.end)
}

/** Plain-data snapshot of what would go out on `Send`. */
data class PromptBarOutgoing(
    val text: String,
    val attachments: List<PromptAttachment>,
    val model: ModelOption?,
)

/**
 * Create and remember a [PromptBarState]. Pass a custom [tokenizer] if you need exact token
 * counts (e.g. a port of tiktoken); the default is a ~4-chars-per-token approximation.
 */
@Composable
fun rememberPromptBarState(
    initialText: String = "",
    initialAttachments: List<PromptAttachment> = emptyList(),
    tokenizer: (String) -> Int = ::approximateTokenCount,
    maxAttachments: Int = 10,
    maxChars: Int = 32_000,
): PromptBarState = remember(maxAttachments, maxChars) {
    PromptBarState(initialText, initialAttachments, tokenizer, maxAttachments, maxChars)
}
