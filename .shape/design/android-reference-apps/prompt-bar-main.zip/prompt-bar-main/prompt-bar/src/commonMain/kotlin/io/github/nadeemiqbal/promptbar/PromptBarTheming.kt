package io.github.nadeemiqbal.promptbar

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Colour tokens for [PromptBar] and its sub-components. Build one with
 * [PromptBarDefaults.colors] (which sources sensible defaults from the active `MaterialTheme`)
 * and override only the slots you want to rebrand:
 *
 * ```kotlin
 * PromptBar(
 *     state = state,
 *     onSend = ::send,
 *     colors = PromptBarDefaults.colors(
 *         sendButtonContainer = Brandblue,
 *         sendButtonContent = Color.White,
 *         cursorColor = Brandblue,
 *     ),
 * )
 * ```
 */
@Immutable
data class PromptBarColors(
    /** Composer card background. */
    val container: Color,
    /** Typed text colour. */
    val textColor: Color,
    /** Placeholder text colour. */
    val placeholderColor: Color,
    /** Text-field caret colour. */
    val cursorColor: Color,
    /** Char/token counter colour. */
    val counterColor: Color,
    /** Send/Stop button background. */
    val sendButtonContainer: Color,
    /** Send/Stop button icon + progress colour. */
    val sendButtonContent: Color,
    /** Attachment chip background. */
    val attachmentChipContainer: Color,
    /** Attachment chip text + preview-icon colour. */
    val attachmentChipContent: Color,
    /** Background of the square preview thumbnail inside an attachment chip. */
    val attachmentPreviewBackground: Color,
)

/**
 * Swappable icon set for [PromptBar]. Build one with [PromptBarDefaults.icons] and pass your own
 * [ImageVector]s to rebrand. Every field defaults to the Material `Outlined` icon the library
 * shipped with, so overriding one icon leaves the rest untouched.
 *
 * ```kotlin
 * PromptBar(
 *     state = state,
 *     onSend = ::send,
 *     icons = PromptBarDefaults.icons(send = MyPaperPlane, mic = MyMic),
 * )
 * ```
 */
@Immutable
data class PromptBarIcons(
    /** Shown on the trailing button in Ready / Disabled states. */
    val send: ImageVector,
    /** Shown on the trailing button while a reply streams. */
    val stop: ImageVector,
    /** Shown on the built-in voice button (when `onVoiceTap` is used). */
    val mic: ImageVector,
    /** Attachment-chip preview icon for [AttachmentPreview.Image]. */
    val attachmentImage: ImageVector,
    /** Attachment-chip preview icon for [AttachmentPreview.File]. */
    val attachmentFile: ImageVector,
    /** Attachment-chip preview icon for [AttachmentPreview.Voice]. */
    val attachmentVoice: ImageVector,
)
