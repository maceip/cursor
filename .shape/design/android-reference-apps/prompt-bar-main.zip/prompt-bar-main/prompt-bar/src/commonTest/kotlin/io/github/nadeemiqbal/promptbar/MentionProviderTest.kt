package io.github.nadeemiqbal.promptbar

import kotlinx.coroutines.test.runTest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class MentionProviderTest {

    @Test
    fun emptyProviderReturnsEmpty() = runTest {
        val result = MentionProvider.Empty.suggest("anything")
        assertTrue(result.isEmpty())
    }

    @Test
    fun fromList_emptyQueryReturnsAll() = runTest {
        val items = listOf(
            Mention("a", "alice"),
            Mention("b", "bob"),
            Mention("c", "carol"),
        )
        val result = MentionProvider.fromList(items).suggest("")
        assertEquals(3, result.size)
    }

    @Test
    fun fromList_filtersCaseInsensitive() = runTest {
        val items = listOf(
            Mention("a", "Alice"),
            Mention("b", "Bob"),
            Mention("c", "Charlie"),
            Mention("d", "alex"),
        )
        val result = MentionProvider.fromList(items).suggest("al")
        assertEquals(setOf("Alice", "alex"), result.map { it.display }.toSet())
    }

    @Test
    fun fromList_noMatchReturnsEmpty() = runTest {
        val items = listOf(Mention("a", "alice"))
        val result = MentionProvider.fromList(items).suggest("xyz")
        assertTrue(result.isEmpty())
    }
}
