package io.github.nadeemiqbal.promptbar

import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNull
import kotlin.test.assertTrue

class PromptBarStateTest {

    @Test
    fun freshState_isDisabled_andEmpty() {
        val state = PromptBarState()
        assertEquals("", state.text)
        assertEquals(SendState.Disabled, state.sendState)
        assertEquals(0, state.charCount)
        assertTrue(state.attachments.isEmpty())
        assertNull(state.selectedModel)
    }

    @Test
    fun typingText_flipsToReady() {
        val state = PromptBarState()
        state.fieldValue = TextFieldValue("hi")
        assertEquals(SendState.Ready, state.sendState)
        assertEquals(2, state.charCount)
    }

    @Test
    fun blankTextWithAttachment_isStillReady() {
        val state = PromptBarState()
        state.addAttachment(PromptAttachment("a1", "foo.txt", AttachmentPreview.File("txt")))
        assertEquals(SendState.Ready, state.sendState)
    }

    @Test
    fun whitespaceOnly_isDisabled() {
        val state = PromptBarState()
        state.fieldValue = TextFieldValue("   \n  ")
        assertEquals(SendState.Disabled, state.sendState)
    }

    @Test
    fun maxCharsTruncatesInput() {
        val state = PromptBarState(maxChars = 10)
        state.fieldValue = TextFieldValue("a".repeat(20))
        assertEquals(10, state.text.length)
    }

    @Test
    fun addAttachment_capRespected() {
        val state = PromptBarState(maxAttachments = 2)
        assertTrue(state.addAttachment(PromptAttachment("a", "1", AttachmentPreview.File("txt"))))
        assertTrue(state.addAttachment(PromptAttachment("b", "2", AttachmentPreview.File("txt"))))
        assertFalse(state.addAttachment(PromptAttachment("c", "3", AttachmentPreview.File("txt"))))
        assertEquals(2, state.attachments.size)
    }

    @Test
    fun addAttachment_duplicateIdRejected() {
        val state = PromptBarState()
        assertTrue(state.addAttachment(PromptAttachment("a", "first", AttachmentPreview.File("txt"))))
        assertFalse(state.addAttachment(PromptAttachment("a", "dup", AttachmentPreview.File("txt"))))
        assertEquals("first", state.attachments[0].displayName)
    }

    @Test
    fun removeAttachment_byId() {
        val state = PromptBarState()
        state.addAttachment(PromptAttachment("a", "1", AttachmentPreview.File("txt")))
        state.addAttachment(PromptAttachment("b", "2", AttachmentPreview.File("txt")))
        state.removeAttachment("a")
        assertEquals(1, state.attachments.size)
        assertEquals("b", state.attachments[0].id)
    }

    @Test
    fun markSendingThenStreamingThenReady() {
        val state = PromptBarState()
        state.fieldValue = TextFieldValue("hi")
        state.markSending()
        assertEquals(SendState.Sending, state.sendState)
        state.markStreaming()
        assertEquals(SendState.Streaming, state.sendState)
        state.markReady()
        // Reverts to derived: text "hi" + no attachments → Ready.
        assertEquals(SendState.Ready, state.sendState)
    }

    @Test
    fun applyTemplateReplacesText() {
        val state = PromptBarState()
        state.fieldValue = TextFieldValue("old")
        state.applyTemplate(PromptTemplate("Summarize", "Please summarize the above text."))
        assertEquals("Please summarize the above text.", state.text)
    }

    @Test
    fun appendAtCaret_insertsBetweenSplit() {
        val state = PromptBarState()
        state.fieldValue = TextFieldValue("Hello world", selection = TextRange(5))
        state.appendAtCaret(",")
        assertEquals("Hello, world", state.text)
    }

    @Test
    fun pasteTokensAsAttachments_buildsChips() {
        val state = PromptBarState(maxAttachments = 5)
        val inserted = state.pasteTokensAsAttachments("a@x.com, b@y.com\nc@z.com") { tok ->
            PromptAttachment(id = tok, displayName = tok, preview = AttachmentPreview.File("eml"))
        }
        assertEquals(3, inserted)
        assertEquals(3, state.attachments.size)
        assertEquals("a@x.com", state.attachments[0].id)
    }

    @Test
    fun resetClearsEverything() {
        val state = PromptBarState()
        state.fieldValue = TextFieldValue("hi")
        state.addAttachment(PromptAttachment("a", "x", AttachmentPreview.File("txt")))
        state.markStreaming()
        state.selectModel(ModelOption("gpt-4", "GPT-4"))
        state.reset()
        assertEquals("", state.text)
        assertTrue(state.attachments.isEmpty())
        // Selected model is intentionally NOT cleared by reset.
        assertEquals("gpt-4", state.selectedModel?.id)
        assertEquals(SendState.Disabled, state.sendState)
    }

    @Test
    fun activeTriggerReflectsCaret() {
        val state = PromptBarState()
        state.fieldValue = TextFieldValue("/hel", selection = TextRange(4))
        val trigger = state.activeTrigger
        assertTrue(trigger is ActiveTrigger.Slash)
        assertEquals("hel", trigger.query)
    }

    @Test
    fun outgoingSnapshotReflectsState() {
        val state = PromptBarState()
        state.fieldValue = TextFieldValue("hi")
        state.addAttachment(PromptAttachment("a", "x", AttachmentPreview.File("txt")))
        state.selectModel(ModelOption("haiku", "Haiku"))
        val out = state.outgoing
        assertEquals("hi", out.text)
        assertEquals(1, out.attachments.size)
        assertEquals("haiku", out.model?.id)
    }

    @Test
    fun customTokenizerIsUsed() {
        val state = PromptBarState(tokenizer = { _ -> 42 })
        state.fieldValue = TextFieldValue("anything")
        assertEquals(42, state.tokenCount)
    }
}
