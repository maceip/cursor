package io.github.nadeemiqbal.promptbar

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class TokenizationTest {

    // ---- detectActiveTrigger ----------------------------------------------------------------

    @Test
    fun noTriggerForPlainText() {
        assertEquals(ActiveTrigger.None, detectActiveTrigger("hello", 5))
        assertEquals(ActiveTrigger.None, detectActiveTrigger("hello world", 11))
    }

    @Test
    fun slashAtStartFires() {
        val t = detectActiveTrigger("/hel", 4)
        assertEquals(ActiveTrigger.Slash("hel", 0), t)
    }

    @Test
    fun mentionAtStartFires() {
        val t = detectActiveTrigger("@nad", 4)
        assertEquals(ActiveTrigger.Mention("nad", 0), t)
    }

    @Test
    fun slashAfterSpaceFires() {
        val t = detectActiveTrigger("hi /cle", 7)
        assertEquals(ActiveTrigger.Slash("cle", 3), t)
    }

    @Test
    fun mentionInsideEmailDoesNotFire() {
        // `email@domain` shouldn't open the mention dropdown.
        assertEquals(ActiveTrigger.None, detectActiveTrigger("email@dom", 9))
    }

    @Test
    fun spaceClosesActiveTrigger() {
        // Once a space follows the trigger run, the trigger closes.
        assertEquals(ActiveTrigger.None, detectActiveTrigger("/help world", 11))
    }

    @Test
    fun caretBeforeTriggerIsNotActive() {
        assertEquals(ActiveTrigger.None, detectActiveTrigger("/help", 0))
    }

    @Test
    fun emptyQueryStillFires() {
        assertEquals(ActiveTrigger.Slash("", 0), detectActiveTrigger("/", 1))
        assertEquals(ActiveTrigger.Mention("", 0), detectActiveTrigger("@", 1))
    }

    // ---- insertTriggerReplacement -----------------------------------------------------------

    @Test
    fun replaceSlashRunWithFullCommand() {
        val r = insertTriggerReplacement(
            text = "/cle",
            caretPosition = 4,
            trigger = ActiveTrigger.Slash("cle", 0),
            replacement = "/clear",
        )
        assertEquals("/clear ", r.newText)
        assertEquals(7, r.newCaretPosition)
    }

    @Test
    fun replaceMentionPreservesSurroundingText() {
        val r = insertTriggerReplacement(
            text = "Hey @nad how are you?",
            caretPosition = 8, // after `@nad`
            trigger = ActiveTrigger.Mention("nad", 4),
            replacement = "@nadeem",
        )
        assertEquals("Hey @nadeem  how are you?", r.newText)
        assertEquals(12, r.newCaretPosition)
    }

    @Test
    fun replaceWithoutTrailingSpace() {
        val r = insertTriggerReplacement(
            text = "/h",
            caretPosition = 2,
            trigger = ActiveTrigger.Slash("h", 0),
            replacement = "/help",
            appendSpace = false,
        )
        assertEquals("/help", r.newText)
        assertEquals(5, r.newCaretPosition)
    }

    @Test
    fun replaceWithNoneTriggerIsNoOp() {
        val r = insertTriggerReplacement("abc", 3, ActiveTrigger.None, "X")
        assertEquals("abc", r.newText)
        assertEquals(3, r.newCaretPosition)
    }

    // ---- tokenizePastedBlob ------------------------------------------------------------------

    @Test
    fun commaSeparatedEmailsSplitsAndTrims() {
        val tokens = tokenizePastedBlob("a@x.com, b@y.com, c@z.com")
        assertEquals(listOf("a@x.com", "b@y.com", "c@z.com"), tokens)
    }

    @Test
    fun semicolonsAndNewlinesSplit() {
        val tokens = tokenizePastedBlob("a; b\nc")
        assertEquals(listOf("a", "b", "c"), tokens)
    }

    @Test
    fun emptyBlobYieldsEmpty() {
        assertEquals(emptyList(), tokenizePastedBlob(""))
    }

    @Test
    fun stripsSurroundingQuotes() {
        val tokens = tokenizePastedBlob("\"a@x.com\", 'b@y.com'")
        assertEquals(listOf("a@x.com", "b@y.com"), tokens)
    }

    @Test
    fun dropsEmptyEntries() {
        val tokens = tokenizePastedBlob(",a,,b,")
        assertEquals(listOf("a", "b"), tokens)
    }

    // ---- approximateTokenCount ---------------------------------------------------------------

    @Test
    fun emptyStringIsZeroTokens() {
        assertEquals(0, approximateTokenCount(""))
    }

    @Test
    fun smallStringIsAtLeastOneToken() {
        assertTrue(approximateTokenCount("a") >= 1)
    }

    @Test
    fun roughly4CharsPerToken() {
        // The estimator is ceil(len / 4). 16 chars → 4 tokens; 17 chars → 5.
        assertEquals(4, approximateTokenCount("1234567890123456"))
        assertEquals(5, approximateTokenCount("12345678901234567"))
    }
}
