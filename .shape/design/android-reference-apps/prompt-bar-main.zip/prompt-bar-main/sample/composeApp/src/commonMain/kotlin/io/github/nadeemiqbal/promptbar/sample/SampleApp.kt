package io.github.nadeemiqbal.promptbar.sample

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import io.github.nadeemiqbal.llmtypewriter.SpeedCurve
import io.github.nadeemiqbal.llmtypewriter.StreamingTypewriter
import io.github.nadeemiqbal.llmtypewriter.StreamingTypewriterState
import io.github.nadeemiqbal.llmtypewriter.ThinkingDots
import io.github.nadeemiqbal.llmtypewriter.TypewriterCursor
import io.github.nadeemiqbal.llmtypewriter.TypewriterPhase
import io.github.nadeemiqbal.llmtypewriter.isStreaming
import io.github.nadeemiqbal.llmtypewriter.rememberMarkdownTypewriterRenderer
import io.github.nadeemiqbal.promptbar.AttachmentPreview
import io.github.nadeemiqbal.promptbar.Mention
import io.github.nadeemiqbal.promptbar.MentionProvider
import io.github.nadeemiqbal.promptbar.ModelOption
import io.github.nadeemiqbal.promptbar.PromptAttachment
import io.github.nadeemiqbal.promptbar.PromptBar
import io.github.nadeemiqbal.promptbar.PromptBarColors
import io.github.nadeemiqbal.promptbar.PromptBarDefaults
import io.github.nadeemiqbal.promptbar.PromptBarIcons
import io.github.nadeemiqbal.promptbar.voice.PromptBarWithVoice
import io.github.nadeemiqbal.promptbar.voice.rememberVoiceAttachmentStore
import io.github.nadeemiqbal.promptbar.PromptTemplate
import io.github.nadeemiqbal.promptbar.SlashCommand
import io.github.nadeemiqbal.promptbar.rememberPromptBarState
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch

/**
 * AI chat starter kit demo — `PromptBar` (this library) + `llm-typewriter`.
 *
 * - User types in PromptBar → presses Send (Enter, IME Send, or the button).
 * - The user message lands in the chat list as a plain bubble.
 * - The fake "assistant" begins streaming a markdown reply through `StreamingTypewriter`:
 *   tokens arrive one-by-one, the renderer paints headings + code blocks progressively, and
 *   the typewriter shows the standard "thinking" dots → revealing → done lifecycle.
 * - PromptBar's Send button flips to **Stop** while a reply is streaming — tap to interrupt
 *   gracefully.
 *
 * That's the whole pitch: drop in both libraries, ship a ChatGPT-quality streaming UI on
 * every CMP target.
 */
@Composable
fun SampleApp() {
    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            ChatScreen()
        }
    }
}

/** A single chat-bubble worth of state in the demo. */
private sealed class ChatItem {
    abstract val id: Int

    data class User(override val id: Int, val text: String) : ChatItem()

    /**
     * Assistant message. Owns its own [StreamingTypewriterState] (so the typewriter survives
     * recompositions) and the [tokens] flow it pumps into the state.
     */
    class Assistant(
        override val id: Int,
        val tokens: MutableSharedFlow<String>,
        val state: StreamingTypewriterState,
    ) : ChatItem()
}

/** Pre-canned markdown replies the fake assistant cycles through. */
private val FakeReplies = listOf(
    """
        Sure — here's a quick **Kotlin** snippet that computes the *Fibonacci sequence*
        recursively.

        ```kotlin
        fun fib(n: Int): Int {
            // Classic recursive form — exponential, but illustrative.
            if (n < 2) return n
            return fib(n - 1) + fib(n - 2)
        }
        ```

        For production, prefer the iterative form — it runs in `O(n)` time and uses constant
        memory.
    """.trimIndent(),

    """
        # Quick summary

        - **PromptBar** owns the input: slash commands, `@`-mentions, attachments, Send/Stop.
        - **LlmTypewriter** owns the output: streaming `Flow<String>`, live markdown,
          syntax-highlighted code blocks.
        - Together they form an **AI chat starter kit** for Compose Multiplatform.

        See [the docs](https://github.com/NadeemIqbal/llm-typewriter) for more.
    """.trimIndent(),

    """
        Here's a Python alternative:

        ```python
        def fib(n):
            # Iterative — O(n) time, O(1) extra memory.
            a, b = 0, 1
            for _ in range(n):
                a, b = b, a + b
            return a
        ```

        Same idea — different language. The typewriter highlights both.
    """.trimIndent(),
)

/**
 * A bundled composer look (colours + icons + shapes), demoing prompt-bar's theming API. The
 * sample toggles between two presets to show how completely a consumer can rebrand the bar.
 */
private data class ComposerStyle(
    val name: String,
    val colors: PromptBarColors,
    val icons: PromptBarIcons,
    val shape: Shape,
    val chipShape: Shape,
    val accent: Color,
)

/** WhatsApp-flavoured preset: green accent, pill shapes, filled paper-plane + filled mic. */
@Composable
private fun whatsAppStyle(): ComposerStyle {
    val green = Color(0xFF25D366)
    return ComposerStyle(
        name = "WhatsApp",
        accent = green,
        colors = PromptBarDefaults.colors(
            sendButtonContainer = green,
            sendButtonContent = Color.White,
            cursorColor = green,
        ),
        icons = PromptBarDefaults.icons(
            send = Icons.AutoMirrored.Filled.Send,
            mic = Icons.Filled.Mic,
        ),
        shape = RoundedCornerShape(26.dp),
        chipShape = RoundedCornerShape(18.dp),
    )
}

/** Telegram-flavoured preset: blue accent, squarer shapes, the default outlined icon set. */
@Composable
private fun telegramStyle(): ComposerStyle {
    val blue = Color(0xFF2AABEE)
    return ComposerStyle(
        name = "Telegram",
        accent = blue,
        colors = PromptBarDefaults.colors(
            sendButtonContainer = blue,
            sendButtonContent = Color.White,
            cursorColor = blue,
        ),
        icons = PromptBarDefaults.icons(),
        shape = RoundedCornerShape(12.dp),
        chipShape = RoundedCornerShape(8.dp),
    )
}

/** Pill segmented toggle for switching the composer style. Selected pill uses the style accent. */
@Composable
private fun StyleToggle(
    styles: List<ComposerStyle>,
    selectedName: String,
    onSelect: (String) -> Unit,
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
    ) {
        styles.forEach { s ->
            val selected = s.name == selectedName
            Text(
                text = s.name,
                style = MaterialTheme.typography.labelMedium,
                color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (selected) s.accent else Color.Transparent)
                    .clickable { onSelect(s.name) }
                    .padding(horizontal = 14.dp, vertical = 7.dp),
            )
        }
    }
}

@Composable
private fun ChatScreen() {
    val promptState = rememberPromptBarState()
    val voiceStore = rememberVoiceAttachmentStore()

    // Theming demo: toggle the composer between two brand presets at runtime.
    val whatsApp = whatsAppStyle()
    val telegram = telegramStyle()
    var styleName by remember { mutableStateOf(whatsApp.name) }
    val style = if (styleName == whatsApp.name) whatsApp else telegram
    val scope = rememberCoroutineScope()

    val messages = remember { mutableStateListOf<ChatItem>() }
    var nextId by remember { mutableStateOf(1) }
    val listState = rememberLazyListState()

    // The currently-streaming assistant message + its driver job. Tracked so the Stop button
    // can cancel mid-stream and the Send button knows whether to send or stop.
    var streamingItem by remember { mutableStateOf<ChatItem.Assistant?>(null) }
    var streamingJob by remember { mutableStateOf<Job?>(null) }
    var replyIndex by remember { mutableStateOf(0) }

    val slashCommands = remember {
        listOf(
            SlashCommand("clear", "Clear the conversation") {
                messages.clear()
                streamingJob?.cancel()
                streamingItem = null
                promptState.markReady()
            },
            SlashCommand("help", "Show available commands"),
            SlashCommand("imagine", "Generate an image", hotkey = "Cmd+I"),
            SlashCommand("code", "Switch to coding mode", hotkey = "Cmd+K"),
        )
    }

    val mentionProvider = remember {
        MentionProvider.fromList(
            listOf(
                Mention("file-readme", "README.md", subtitle = "Project root", category = "File"),
                Mention("file-main", "Main.kt", subtitle = "src/main/kotlin", category = "File"),
                Mention("person-nadeem", "Nadeem Iqbal", subtitle = "owner@example.com", category = "Person"),
                Mention("person-sara", "Sara", subtitle = "sara@example.com", category = "Person"),
            ),
        )
    }

    val templates = remember {
        listOf(
            PromptTemplate("Summarize", "Summarize the conversation so far."),
            PromptTemplate("Explain code", "Explain what this code does:\n\n```kotlin\n\n```"),
            PromptTemplate("Fix bug", "I have a bug in the following code — can you spot it?\n\n"),
        )
    }

    val models = remember {
        listOf(
            ModelOption("haiku", "Haiku 4.5", "Fast, cheap"),
            ModelOption("sonnet", "Sonnet 4.6", "Balanced"),
            ModelOption("opus", "Opus 4.7", "Smartest, slowest"),
        )
    }
    if (promptState.selectedModel == null) {
        LaunchedEffect(Unit) { promptState.selectModel(models.first()) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .background(MaterialTheme.colorScheme.background),
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column {
                Text("AI Chat — Compose Multiplatform", style = MaterialTheme.typography.titleMedium)
                Text(
                    "prompt-bar + llm-typewriter · ${style.name} style",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            // Style toggle: switches the composer's colours / icons / shapes live.
            StyleToggle(
                styles = listOf(whatsApp, telegram),
                selectedName = styleName,
                onSelect = { styleName = it },
            )
        }

        // Message list
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
        ) {
            items(messages, key = { it.id }) { item ->
                when (item) {
                    is ChatItem.User -> UserBubble(item.text)
                    is ChatItem.Assistant -> AssistantBubble(item)
                }
            }
        }

        // Composer
        Box(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            PromptBarWithVoice(
                state = promptState,
                voiceStore = voiceStore,
                colors = style.colors,
                icons = style.icons,
                shape = style.shape,
                chipShape = style.chipShape,
                onSend = {
                    if (promptState.text.isBlank() && promptState.attachments.isEmpty()) return@PromptBarWithVoice
                    val userId = nextId++
                    // Claim any voice attachments' bytes from the store. The demo doesn't actually
                    // upload them anywhere, but the side effect surfaces them in the chat
                    // bubble's attachment summary so we can confirm the wiring is real.
                    val voiceCount = promptState.attachments.count { att ->
                        voiceStore.take(att.id) != null
                    }
                    val userText = buildString {
                        append(promptState.text.trim())
                        if (promptState.attachments.isNotEmpty()) {
                            append("\n[${promptState.attachments.size} attachment(s): ")
                            append(promptState.attachments.joinToString(", ") { it.displayName })
                            if (voiceCount > 0) append("; $voiceCount voice")
                            append("]")
                        }
                    }
                    messages.add(ChatItem.User(userId, userText))
                    promptState.reset()

                    val assistantId = nextId++
                    val tokens = MutableSharedFlow<String>(extraBufferCapacity = 64)
                    val typewriterState = StreamingTypewriterState()
                    val assistant = ChatItem.Assistant(assistantId, tokens, typewriterState)
                    messages.add(assistant)
                    streamingItem = assistant

                    // Flip PromptBar's Send button to Stop while the reply streams.
                    promptState.markStreaming()

                    streamingJob = scope.launch {
                        listState.animateScrollToItem(messages.size - 1)
                        // Pretend the model "thinks" before the first token arrives.
                        delay(500)
                        val reply = FakeReplies[replyIndex % FakeReplies.size]
                        replyIndex++
                        try {
                            streamReply(reply, tokens)
                        } finally {
                            // Whether the stream completed normally or was cancelled,
                            // restore the Send button.
                            promptState.markReady()
                            streamingItem = null
                            streamingJob = null
                        }
                    }
                },
                onStop = {
                    // User hit Stop while a reply is streaming. Two things happen:
                    //   1. Cancel the coroutine pumping tokens into the flow.
                    //   2. Tell the typewriter to stop revealing — it shows "(stopped)".
                    streamingJob?.cancel()
                    streamingItem?.state?.stop()
                    // `markReady` also fires in the streamingJob's `finally` block, but call
                    // it here too so the button flips back instantly without waiting for the
                    // coroutine cancellation to propagate.
                    promptState.markReady()
                },
                // onVoiceTap is gone in the new PromptBarWithVoice composable: voice recording
                // is wired in via the voice-message + voice-message-audio companion, so the
                // fake-attachment placeholder this sample used to drop is no longer needed.
                slashCommands = slashCommands,
                mentionProvider = mentionProvider,
                templates = templates,
                modelSelector = {
                    TextButton(onClick = {
                        val cur = promptState.selectedModel ?: models.first()
                        val idx = models.indexOfFirst { it.id == cur.id }
                        promptState.selectModel(models[(idx + 1) % models.size])
                    }) {
                        Text(
                            promptState.selectedModel?.name ?: "Pick a model",
                            style = MaterialTheme.typography.labelMedium,
                        )
                    }
                },
            )
        }

        Text(
            "Try `/cl` for slash · `@al` for mentions · 🎤 for an attachment chip · " +
                "tap Send and watch the assistant stream in via llm-typewriter.",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .padding(horizontal = 16.dp, vertical = 6.dp),
        )
    }
}

@Composable
private fun UserBubble(text: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        Surface(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .clip(RoundedCornerShape(16.dp, 4.dp, 16.dp, 16.dp)),
            color = MaterialTheme.colorScheme.primaryContainer,
            shape = PromptBarDefaults.chipShape,
        ) {
            Text(
                text,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
        }
    }
}

@Composable
private fun AssistantBubble(item: ChatItem.Assistant) {
    val markdownRenderer = rememberMarkdownTypewriterRenderer()
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
        Surface(
            modifier = Modifier
                .widthIn(max = 320.dp)
                .clip(RoundedCornerShape(4.dp, 16.dp, 16.dp, 16.dp)),
            color = MaterialTheme.colorScheme.surfaceVariant,
            shape = PromptBarDefaults.chipShape,
        ) {
            Box(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                if (item.state.revealed.isEmpty() && item.state.phase != TypewriterPhase.Done) {
                    // While the assistant is "thinking" — empty reveal buffer, no tokens yet —
                    // show the three-dots indicator from the typewriter library.
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        ThinkingDots(dotSize = 6.dp)
                        Text(
                            "Thinking…",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                StreamingTypewriter(
                    tokens = item.tokens,
                    state = item.state,
                    renderer = markdownRenderer,
                    cursor = TypewriterCursor.Line,
                    speedCurve = SpeedCurve.Natural,
                )
            }
        }
    }
}

/** Push the canned reply into the shared flow as word-sized tokens at ~70 ms cadence. */
private suspend fun streamReply(reply: String, channel: MutableSharedFlow<String>) {
    val pieces = mutableListOf<String>()
    val builder = StringBuilder()
    for (ch in reply) {
        builder.append(ch)
        if (ch == ' ' || ch == '\n') {
            pieces.add(builder.toString())
            builder.clear()
        }
    }
    if (builder.isNotEmpty()) pieces.add(builder.toString())

    for (piece in pieces) {
        delay(70L)
        channel.emit(piece)
    }
}

@Suppress("unused")
private fun retainIsStreaming(state: StreamingTypewriterState) = state.isStreaming
