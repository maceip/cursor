package io.github.nadeemiqbal.promptbar.sample.desktop

import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import io.github.nadeemiqbal.promptbar.sample.SampleApp

fun main() = application {
    Window(
        onCloseRequest = ::exitApplication,
        title = "PromptBar Sample",
        state = rememberWindowState(width = 720.dp, height = 800.dp),
    ) {
        SampleApp()
    }
}
