# Changelog

All notable changes to this project are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.3.0] - 2026-05-29

### Added

- **Theming API.** `PromptBar` now takes `colors: PromptBarColors`, `icons: PromptBarIcons`,
  `shape`, and `chipShape`. Build the first two with `PromptBarDefaults.colors(...)` /
  `PromptBarDefaults.icons(...)`, which default every token to the active `MaterialTheme` and the
  Material Outlined icon set, so you override only what you want to rebrand. Covers container,
  text, placeholder, cursor, counter, send-button container/content, and attachment-chip colours;
  and the send / stop / mic / image / file / voice icons. `SendStopButton` and `AttachmentChip`
  gained matching `colors` / `icons` params. Previously only global `MaterialTheme` re-theming
  worked and icons/shapes were hardcoded.
- **`prompt-bar-voice` `PromptBarWithVoice`** WhatsApp-style composer: the trailing button is a
  hold-to-record mic when the field is empty and morphs (animated) into Send when you type;
  holding the mic takes over the text-field area with a live recording strip; releasing drops an
  `AttachmentPreview.Voice` chip. `PromptBarWithVoice` forwards the new theming params too.

### Fixed

- **Locked-mode voice send was impossible.** When a recording locked hands-free, the trailing
  control fell through to the normal `SendStopButton`, whose `enabled` is gated on the text
  `SendState` (which is `Disabled` while the field is empty) - so the locked recording could
  never be sent. Locked mode now shows a dedicated always-enabled send button wired to
  `sendFromLock()`.
- **Recording-strip background mismatch.** The strip painted a flat `surface` colour that didn't
  match the PromptBar card's `surface` + 1.dp tonal elevation, so it looked white against the
  card. The strip is now transparent and the placeholder behind it is suppressed while the
  overlay is active, so the card surface shows through and matches exactly.

## [0.2.0] - 2026-05-29

### Added

- **New artifact: `prompt-bar-voice`** at the matching `0.2.0`. Drop-in companion that wires
  the platform mic into prompt-bar via `voice-message` + `voice-message-audio` (both at
  `0.3.0`). Use `PromptBarWithVoice` in place of `PromptBar` and the inert mic icon is replaced
  with a real hold-to-record control. Completed recordings appear as voice attachment chips
  above the text field; the raw `VoiceAudio` bytes are addressable by attachment id through
  the new `VoiceAttachmentStore`.
- **`AttachmentPreview.Voice(durationSeconds, samples)`** variant on `PromptAttachment`. Lets
  the attachment chip carry per-bar amplitude data so its preview can match the waveform the
  user saw while recording. The chip is rendered with an `Icons.Outlined.GraphicEq` icon by
  default; use `customAttachmentPreview` to swap in a richer visual.

### Notes

- The core `prompt-bar` artifact takes no new dependencies. Voice support is strictly opt-in
  through the `prompt-bar-voice` companion.
- Adding `Voice` to the `sealed class AttachmentPreview` is technically a source-incompatible
  change for callers who exhaustively `when`-match on the variants without an `else` branch.
  Most consumers let prompt-bar render attachments and only inspect the variant inside
  `customAttachmentPreview`, so the practical break is small. Bumped to a minor version
  (`0.2.0`) rather than a patch out of an abundance of caution.

## [0.1.0] - 2026-05-17

### Added
- Initial release of `PromptBar` for Compose Multiplatform.
- `PromptBar` — the composer composable. Auto-growing multi-line textfield, attachment chips,
  templates row, autocomplete panels, voice button, model selector slot, send/stop button.
- `PromptBarState` + `rememberPromptBarState` — headless state container.
  - `fieldValue` (TextFieldValue), `text`, `attachments`, `selectedModel`, `sendState`,
    `activeTrigger`, `charCount`, `tokenCount`, `outgoing` (snapshot).
  - `addAttachment`, `removeAttachment`, `clearAttachments`.
  - `markSending`, `markStreaming`, `markReady`, `forceSendState` — send-button state machine
    overrides.
  - `applyTemplate`, `appendAtCaret`, `pasteTokensAsAttachments` — text manipulation helpers.
  - `selectModel`, `reset`.
  - Pluggable `tokenizer: (String) -> Int` for accurate token counting.
- `SlashCommand` + `SlashAutocompletePanel` — `/cmd` autocomplete dropdown with hotkey chips.
- `Mention`, `MentionProvider` (async `suggest(query)`), `MentionAutocompletePanel` — `@mention`
  dropdown. `MentionProvider.Empty` and `MentionProvider.fromList` helpers.
- `AttachmentChip` + `AttachmentPreview` (`Image`, `File`) + `PromptAttachment` —
  attachment chips with built-in image/file icons or custom preview composable.
- `PromptTemplate` — quick-start prompt chips above the input.
- `ModelOption` + a slot for any inline model selector composable.
- `SendStopButton` + `SendState` — single button that toggles Send → Sending → Stop based on
  the lifecycle.
- `detectActiveTrigger`, `insertTriggerReplacement` — pure-logic helpers for the autocomplete
  state machine (no composition required).
- `tokenizePastedBlob` — smart paste-tokenizer that splits comma/semicolon/newline blobs and
  strips surrounding quotes; used by `pasteTokensAsAttachments`.
- `approximateTokenCount` — ~4-chars-per-token estimator used as the default for the live counter.
- Keyboard shortcuts: `Enter` sends (when in `Ready`), `Shift+Enter` newline, `ImeAction.Send`
  on mobile keyboards.
- 35+ pure-logic tests + 14 Compose UI tests.
- Targets: Android (minSdk 24), iOS (x64, arm64, simulatorArm64), Desktop (JVM 11), Web (wasmJs).

[Unreleased]: https://github.com/NadeemIqbal/prompt-bar/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/NadeemIqbal/prompt-bar/releases/tag/v0.1.0
