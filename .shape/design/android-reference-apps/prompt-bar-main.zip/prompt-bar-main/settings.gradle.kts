pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
    }
}

rootProject.name = "prompt-bar"

include(":prompt-bar")
include(":prompt-bar-voice")
include(":sample:composeApp")
include(":sample:androidApp")
include(":sample:desktopApp")
include(":sample:webApp")
// iOS sample is a standalone Xcode project — not a Gradle module.
