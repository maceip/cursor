package io.github.nadeemiqbal.promptbar.voice

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import io.github.nadeemiqbal.voicemessage.audio.VoiceAudio

/**
 * Composition-scoped map from `PromptAttachment.id` to the captured [VoiceAudio] bytes.
 *
 * `prompt-bar`'s `PromptAttachment` is intentionally immutable + lightweight (id, displayName,
 * preview), so the audio bytes can't ride along inside it. The store keeps them addressable by
 * id so the consumer's submit handler can retrieve and upload them in a single pass.
 *
 * Typical usage:
 *
 * ```kotlin
 * val voiceStore = rememberVoiceAttachmentStore()
 * PromptBarWithVoice(
 *     state = promptBarState,
 *     voiceStore = voiceStore,
 *     onSend = {
 *         val text = promptBarState.fieldValue.text
 *         val voiceAudios = promptBarState.attachments
 *             .filter { it.preview is AttachmentPreview.Voice }
 *             .mapNotNull { att -> voiceStore.take(att.id)?.let { att.id to it } }
 *             .toMap()
 *         upload(text, voiceAudios)
 *         promptBarState.fieldValue = TextFieldValue("")
 *     },
 * )
 * ```
 *
 * The store survives recomposition for as long as its enclosing composition lives, and is
 * cleared on composition leave. Use [take] (not [get]) in submit handlers so the bytes are
 * released as soon as the consumer has them.
 */
@Stable
class VoiceAttachmentStore internal constructor() {
    private val map = mutableStateMapOf<String, VoiceAudio>()

    /** Inserts an audio payload under [id]. Overwrites any prior entry with the same id. */
    internal fun put(id: String, audio: VoiceAudio) {
        map[id] = audio
    }

    /** Returns the audio for [id] without removing it. Returns `null` if not present. */
    fun get(id: String): VoiceAudio? = map[id]

    /** Returns and removes the audio for [id]. Use this in submit handlers. */
    fun take(id: String): VoiceAudio? = map.remove(id)

    /** Drops every entry. Call when the prompt-bar's attachment list is cleared too. */
    fun clear() {
        map.clear()
    }

    /** Number of voice attachments currently tracked. */
    val size: Int get() = map.size
}

/** Creates and remembers a [VoiceAttachmentStore]. */
@Composable
fun rememberVoiceAttachmentStore(): VoiceAttachmentStore = remember { VoiceAttachmentStore() }
