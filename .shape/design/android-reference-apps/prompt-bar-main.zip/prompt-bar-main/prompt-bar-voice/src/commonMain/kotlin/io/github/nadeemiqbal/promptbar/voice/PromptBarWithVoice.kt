package io.github.nadeemiqbal.promptbar.voice

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Send
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.unit.dp
import io.github.nadeemiqbal.promptbar.AttachmentPreview
import io.github.nadeemiqbal.promptbar.MentionProvider
import io.github.nadeemiqbal.promptbar.PromptAttachment
import io.github.nadeemiqbal.promptbar.PromptBar
import io.github.nadeemiqbal.promptbar.PromptBarColors
import io.github.nadeemiqbal.promptbar.PromptBarDefaults
import io.github.nadeemiqbal.promptbar.PromptBarIcons
import io.github.nadeemiqbal.promptbar.PromptBarState
import io.github.nadeemiqbal.promptbar.PromptTemplate
import io.github.nadeemiqbal.promptbar.SendState
import io.github.nadeemiqbal.promptbar.SendStopButton
import io.github.nadeemiqbal.promptbar.SlashCommand
import io.github.nadeemiqbal.voicemessage.VoiceMessageDefaults
import io.github.nadeemiqbal.voicemessage.VoiceMicButton
import io.github.nadeemiqbal.voicemessage.VoicePhase
import io.github.nadeemiqbal.voicemessage.VoiceRecorderState
import io.github.nadeemiqbal.voicemessage.VoiceWaveform
import io.github.nadeemiqbal.voicemessage.audio.VoiceAudio
import io.github.nadeemiqbal.voicemessage.audio.rememberAudioBoundVoiceRecorderState
import kotlin.random.Random
import kotlin.time.Duration

/**
 * Drop-in replacement for [PromptBar] that turns the composer into a WhatsApp-style voice input:
 *
 * - **Empty field** -> the trailing button is a hold-to-record mic.
 * - **User types** -> the mic morphs (animated) into the Send button.
 * - **Hold the mic** -> the "Send a message..." text-field area is taken over by a live recording
 *   strip (blinking dot, timer, scrolling waveform, slide-to-cancel hint). Slide up to lock,
 *   slide toward the cancel edge to arm cancel-on-release.
 * - **Release** (or tap Send while locked) -> the recording becomes an `AttachmentPreview.Voice`
 *   chip above the field, and the raw [VoiceAudio] bytes land in [voiceStore] keyed by the
 *   attachment id.
 *
 * Built on prompt-bar's `trailingButton` + `inputOverlay` slots and voice-message's public
 * `VoiceMicButton` / `VoiceWaveform`, so the standard prompt-bar layout (chips, autocomplete,
 * counter, model selector) is preserved exactly. Parameters mirror [PromptBar] minus
 * `onVoiceTap` (the mic is the trailing button now).
 */
@Composable
fun PromptBarWithVoice(
    state: PromptBarState,
    onSend: () -> Unit,
    modifier: Modifier = Modifier,
    voiceStore: VoiceAttachmentStore = rememberVoiceAttachmentStore(),
    onStop: (() -> Unit)? = null,
    onVoiceCaptured: ((PromptAttachment, VoiceAudio) -> Unit)? = null,
    placeholder: String = PromptBarDefaults.DefaultPlaceholder,
    slashCommands: List<SlashCommand> = emptyList(),
    mentionProvider: MentionProvider = MentionProvider.Empty,
    templates: List<PromptTemplate> = emptyList(),
    showCounter: Boolean = true,
    colors: PromptBarColors = PromptBarDefaults.colors(),
    icons: PromptBarIcons = PromptBarDefaults.icons(),
    shape: androidx.compose.ui.graphics.Shape = PromptBarDefaults.shape,
    chipShape: androidx.compose.ui.graphics.Shape = PromptBarDefaults.chipShape,
    modelSelector: (@Composable () -> Unit)? = null,
    customAttachmentPreview: ((PromptAttachment) -> (@Composable () -> Unit)?)? = null,
) {
    var counter by remember { mutableStateOf(0) }
    val recorderState = rememberAudioBoundVoiceRecorderState(
        onSend = { audio, samples ->
            counter += 1
            val id = "voice-$counter-${Random.nextInt(1_000_000)}"
            val attachment = PromptAttachment(
                id = id,
                displayName = formatVoiceName(audio.duration),
                preview = AttachmentPreview.Voice(
                    durationSeconds = audio.duration.inWholeSeconds.toInt(),
                    samples = samples,
                ),
                sizeLabel = formatBytes(audio.bytes.size),
            )
            voiceStore.put(id, audio)
            state.addAttachment(attachment)
            onVoiceCaptured?.invoke(attachment, audio)
        },
    )

    val recording = recorderState.phase != VoicePhase.Idle

    PromptBar(
        state = state,
        onSend = onSend,
        modifier = modifier,
        onStop = onStop,
        placeholder = placeholder,
        slashCommands = slashCommands,
        mentionProvider = mentionProvider,
        templates = templates,
        showCounter = showCounter,
        colors = colors,
        icons = icons,
        shape = shape,
        chipShape = chipShape,
        modelSelector = modelSelector,
        customAttachmentPreview = customAttachmentPreview,
        trailingButton = { sendState ->
            TrailingMicOrSend(
                recorderState = recorderState,
                textEmpty = state.text.isEmpty(),
                sendState = sendState,
                onSend = onSend,
                onStop = onStop ?: {},
                colors = colors,
                icons = icons,
            )
        },
        inputOverlay = if (recording) {
            { VoiceRecordingStrip(recorderState, accentColor = colors.sendButtonContainer) }
        } else {
            null
        },
    )
}

private enum class TrailingKind { Mic, LockedSend, Send }

/**
 * The morphing trailing control. Three states:
 *
 * - [TrailingKind.Mic]: field empty and not locked -> hold-to-record mic.
 * - [TrailingKind.LockedSend]: recording is locked hands-free -> an always-enabled send button
 *   that delivers the locked recording via `sendFromLock()`. (Crucially NOT the normal
 *   SendStopButton, whose `enabled` is gated on the text `SendState`, which is `Disabled` while
 *   the field is empty -> the locked recording could never be sent.)
 * - [TrailingKind.Send]: field has text -> the normal Send/Stop button.
 */
@Composable
private fun TrailingMicOrSend(
    recorderState: VoiceRecorderState,
    textEmpty: Boolean,
    sendState: SendState,
    onSend: () -> Unit,
    onStop: () -> Unit,
    colors: PromptBarColors,
    icons: PromptBarIcons,
) {
    val locked = recorderState.phase == VoicePhase.RecordingLocked
    val kind = when {
        locked -> TrailingKind.LockedSend
        textEmpty -> TrailingKind.Mic
        else -> TrailingKind.Send
    }
    // Map the prompt-bar theming tokens onto voice-message's recorder colours so the mic glyph
    // and its recording-highlight follow the active style accent instead of voice-message's
    // own defaults. Idle mic glyph stays neutral (placeholderColor); the highlight + waveform
    // use the accent (sendButtonContainer).
    val recorderColors = VoiceMessageDefaults.recorderColors(
        micColor = colors.placeholderColor,
        micActiveColor = colors.sendButtonContainer,
        waveformColor = colors.sendButtonContainer,
        lockIconColor = colors.sendButtonContainer,
    )
    AnimatedContent(
        targetState = kind,
        transitionSpec = {
            (scaleIn(tween(150)) + fadeIn(tween(150))) togetherWith
                (scaleOut(tween(150)) + fadeOut(tween(150)))
        },
        label = "prompt_bar_voice_morph",
    ) { target ->
        when (target) {
            TrailingKind.Mic -> VoiceMicButton(
                state = recorderState,
                colors = recorderColors,
                icon = icons.mic,
            )
            TrailingKind.LockedSend -> FilledIconButton(
                onClick = { recorderState.sendFromLock() },
                modifier = Modifier.size(40.dp),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = colors.sendButtonContainer,
                    contentColor = colors.sendButtonContent,
                ),
            ) {
                Icon(
                    imageVector = icons.send,
                    contentDescription = "Send voice message",
                )
            }
            TrailingKind.Send -> SendStopButton(
                sendState = sendState,
                onSend = onSend,
                onStop = onStop,
                colors = colors,
                icons = icons,
            )
        }
    }
}

/**
 * The recording strip that overlays the text-field area while capturing: a blinking record dot
 * (or a cancel button when locked), the elapsed timer, a live scrolling waveform, and the
 * slide-to-cancel hint.
 */
@Composable
private fun VoiceRecordingStrip(
    recorderState: VoiceRecorderState,
    accentColor: androidx.compose.ui.graphics.Color,
) {
    val cancelling = recorderState.phase == VoicePhase.Cancelling
    val locked = recorderState.phase == VoicePhase.RecordingLocked
    val errorColor = MaterialTheme.colorScheme.error
    val waveColor = if (cancelling) errorColor else accentColor

    // No background: the strip overlays the textfield area transparently so the PromptBar card's
    // own surface (which carries a 1.dp tonal elevation) shows through and matches exactly. The
    // placeholder behind it is suppressed by PromptBar while inputOverlay is active.
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.CenterStart,
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (locked) {
                IconButton(
                    onClick = { recorderState.cancelFromLock() },
                    modifier = Modifier.size(32.dp),
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Close,
                        contentDescription = "Cancel recording",
                        tint = errorColor,
                    )
                }
            } else {
                val alpha by androidx.compose.animation.core.rememberInfiniteTransition(label = "rec_dot")
                    .animateFloat(
                        initialValue = 1f,
                        targetValue = 0.3f,
                        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
                        label = "rec_dot_alpha",
                    )
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .alpha(alpha)
                        .background(errorColor, CircleShape),
                )
            }
            Text(
                text = formatElapsed(recorderState.elapsed),
                color = MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.width(48.dp),
            )
            VoiceWaveform(
                samples = recorderState.capturedSamples,
                barColor = waveColor,
                live = true,
                modifier = Modifier.weight(1f).height(28.dp),
            )
            Text(
                text = when {
                    cancelling -> "Release to cancel"
                    locked -> ""
                    else -> "← Slide to cancel"
                },
                color = if (cancelling) errorColor else MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.labelSmall,
            )
        }
    }
}

private fun formatVoiceName(duration: Duration): String = "Voice ${formatElapsed(duration)}"

private fun formatElapsed(duration: Duration): String {
    val totalSeconds = duration.inWholeSeconds.coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val seconds = (totalSeconds % 60).toString().padStart(2, '0')
    return "$minutes:$seconds"
}

private fun formatBytes(bytes: Int): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "${bytes / 1024} KB"
    else -> "${bytes / (1024 * 1024)} MB"
}
