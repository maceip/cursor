import org.jetbrains.kotlin.gradle.ExperimentalKotlinGradlePluginApi
import org.jetbrains.kotlin.gradle.ExperimentalWasmDsl
import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.kotlin.multiplatform)
    alias(libs.plugins.android.library)
    alias(libs.plugins.compose.multiplatform)
    alias(libs.plugins.compose.compiler)
    alias(libs.plugins.vanniktech.maven.publish)
}

// Companion artifact for prompt-bar: opt-in voice-message integration so callers can drop in a
// fully wired hold-to-record mic without writing any audio plumbing. Released in lockstep with
// the main prompt-bar artifact (currently 0.2.0).
val libVersion: String =
    (System.getenv("RELEASE_VERSION") ?: findProperty("version") as String?)
        ?.removePrefix("v")
        ?.takeUnless { it.isBlank() || it == "unspecified" }
        ?: "0.3.0"

group = "io.github.nadeemiqbal"
version = libVersion

kotlin {
    @OptIn(ExperimentalKotlinGradlePluginApi::class)
    applyDefaultHierarchyTemplate()

    androidTarget {
        publishLibraryVariants("release")
        compilations.all {
            compileTaskProvider.configure { compilerOptions { jvmTarget.set(JvmTarget.JVM_11) } }
        }
    }

    jvm("desktop") {
        compilations.all {
            compileTaskProvider.configure { compilerOptions { jvmTarget.set(JvmTarget.JVM_11) } }
        }
    }

    iosX64()
    iosArm64()
    iosSimulatorArm64()

    @OptIn(ExperimentalWasmDsl::class)
    wasmJs {
        browser()
    }

    sourceSets {
        commonMain.dependencies {
            // The main library: this artifact extends PromptBar with audio-bound voice recording,
            // so it has a hard dependency on prompt-bar.
            api(project(":prompt-bar"))
            // voice-message-audio brings the real mic capture; voice-message brings the
            // VoiceRecorderInput composable + state machine. Both ship at 0.3.0.
            api("io.github.nadeemiqbal:voice-message:0.3.1")
            api("io.github.nadeemiqbal:voice-message-audio:0.3.1")
            implementation(compose.runtime)
            implementation(compose.foundation)
            implementation(compose.ui)
            implementation(compose.material3)
            implementation(compose.materialIconsExtended)
        }
        commonTest.dependencies {
            implementation(kotlin("test"))
        }
    }
}

android {
    namespace = "io.github.nadeemiqbal.promptbar.voice"
    compileSdk = libs.versions.compileSdk.get().toInt()
    defaultConfig {
        minSdk = libs.versions.minSdk.get().toInt()
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

tasks.matching { it.name == "wasmJsBrowserTest" || it.name == "wasmJsNodeTest" }
    .configureEach { enabled = false }

mavenPublishing {
    publishToMavenCentral()

    if (
        project.hasProperty("signingInMemoryKey") ||
        project.hasProperty("signing.keyId")
    ) {
        signAllPublications()
    }

    coordinates("io.github.nadeemiqbal", "prompt-bar-voice", libVersion)

    pom {
        name.set("PromptBar Voice")
        description.set(
            "Drop-in voice recording for prompt-bar. Pairs PromptBar with " +
                "voice-message + voice-message-audio so the mic button does a real hold-to-record " +
                "and dropped voice messages become attachment chips with embedded waveforms. " +
                "Bytes accessible by attachment id via VoiceAttachmentStore.",
        )
        inceptionYear.set("2026")
        url.set("https://github.com/NadeemIqbal/prompt-bar")
        licenses {
            license {
                name.set("The Apache License, Version 2.0")
                url.set("https://www.apache.org/licenses/LICENSE-2.0.txt")
                distribution.set("https://www.apache.org/licenses/LICENSE-2.0.txt")
            }
        }
        developers {
            developer {
                id.set("NadeemIqbal")
                name.set("Nadeem Iqbal")
                email.set("mr_nadeem_iqbal@yahoo.com")
                url.set("https://github.com/NadeemIqbal")
            }
        }
        scm {
            url.set("https://github.com/NadeemIqbal/prompt-bar")
            connection.set("scm:git:git://github.com/NadeemIqbal/prompt-bar.git")
            developerConnection.set("scm:git:ssh://git@github.com/NadeemIqbal/prompt-bar.git")
        }
    }
}
